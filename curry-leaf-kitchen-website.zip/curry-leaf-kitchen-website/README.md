# Curry Leaf Kitchen — Static Website Package

Everything in this folder is plain HTML/CSS/JS — no build step, no server
required. It's ready to upload as-is to any static host.

## Files

```
index.html           Homepage
all-recipes.html      All Recipes — filterable/searchable listing
recipe-detail.html    Single recipe page (Paneer Butter Masala template)
blog.html             Blog listing
blog-single.html      Single blog post template
robots.txt            Tells search engines they can crawl the site
sitemap.xml            Lists all 5 pages for search engines
```

Every page already links to the others by filename (`index.html`,
`all-recipes.html`, etc.), so the site works correctly the moment you
upload the folder — no path fixing needed.

## Deploy it live — pick one

**Netlify (easiest, free)**
1. Go to [app.netlify.com/drop](https://app.netlify.com/drop)
2. Drag this whole folder onto the page
3. Done — you get a live `https://your-site.netlify.app` URL in seconds
4. Optional: Site settings → Domain management → add your own domain

**Vercel**
1. `npm i -g vercel` (or use the Vercel dashboard's "Add New → Project → Upload")
2. Run `vercel` inside this folder and follow the prompts

**GitHub Pages**
1. Create a new GitHub repo and push this folder's contents to it
2. Repo → Settings → Pages → Source: `main` branch, `/root`
3. Your site is live at `https://yourusername.github.io/reponame/`

**Traditional web hosting (cPanel / FTP)**
1. Upload every file in this folder into your host's `public_html` (or
   `www`/`htdocs`) directory via FTP or the file manager
2. Nothing else to configure — it's static HTML

## Before you go live — 3 things to change

1. **Domain**: every file uses a placeholder domain
   (`https://www.curryleafkitchen.example`) in the `<link rel="canonical">`,
   Open Graph tags, and the JSON-LD schema blocks. Find-and-replace that
   string across all 5 files with your real domain once you have one.
2. **Recipe photos**: the "photos" you see are CSS/SVG illustrations, not
   real photography (kept it that way since no licensed photos were
   available to build this with). Swap the `.photo` divs for real `<img>`
   tags with descriptive `alt` text before launch — this matters for both
   user trust and image SEO.
3. **One recipe page for all recipes**: `recipe-detail.html` is a *template*
   — right now every recipe card on the site links to this same file. For
   a real multi-recipe site, either:
   - duplicate `recipe-detail.html` once per recipe (e.g.
     `recipes/butter-chicken.html`, `recipes/dal-tadka.html`...) and update
     each card's `href` to point at its own file, or
   - use the WordPress template kit provided earlier, which generates
     these pages dynamically from the database instead.

## SEO already built in

- Single `<h1>` per page, keyword-rich `<h2>` sections, every recipe/post
  name in a heading tag
- Meta description, Open Graph, Twitter Card tags on every page
- JSON-LD structured data: `WebSite`, `ItemList`, `Recipe`, `FAQPage`,
  `BlogPosting` and `BreadcrumbList` schema
- Semantic HTML5 (`header`/`nav`/`main`/`article`/`footer`), skip-link,
  ARIA labelling throughout
- `robots.txt` + `sitemap.xml` included — once you have a real domain,
  update both files with it and submit the sitemap in Google Search Console

## Mobile & accessibility

- Mobile-first responsive CSS (works from ~320px up)
- Dark-mode CSS variables included (`prefers-color-scheme`)
- Keyboard-navigable menus, search, and modal; visible focus states
- Respects `prefers-reduced-motion`
